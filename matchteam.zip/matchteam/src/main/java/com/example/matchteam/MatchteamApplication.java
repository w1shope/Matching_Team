package com.example.matchteam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatchteamApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatchteamApplication.class, args);
	}

}
